# Load‑Test Report – 

| Metric | Target | Actual |
|--------|--------|--------|
| p95 dispatch latency | < 300 ms |  |
| Error rate | < 1 % |  |
| Max CPU util (scheduler) | < 70 % |  |
| Avg node throughput |  |  |

## Bottlenecks Observed

## Tuning Applied
