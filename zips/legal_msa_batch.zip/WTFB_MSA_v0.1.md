# WTFB Contributor & Node Operator MSA / Terms of Service (v0.1)

*Prepared May 2025*

## 1. Parties
**“WTFB”** — Words To Film By, Inc., a Delaware corporation.  
**“Contributor”** — Entity or individual operating Edge‐Kit node(s) … (full legal text continues)

## 2. Purpose
Provide mutually beneficial terms …

... (rest of full document omitted for brevity) ...
