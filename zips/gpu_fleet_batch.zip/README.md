GPU fleet batch artefacts.
